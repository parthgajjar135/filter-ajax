<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "testingdemos");
$column = array("vendor_id","branch_id","invoice_no","round_of_amount","invoice_date","delivery_note","buyer_order_no","buyer_order_date", "delivery_date", "dispatch_through");
$query = "
 SELECT * FROM purchase_inward WHERE 
";

if(isset($_POST["is_days"]))
{
 $query .= "invoice_date BETWEEN CURDATE() - INTERVAL ".$_POST["is_days"]." DAY AND CURDATE() AND ";
}

if(isset($_POST["search"]["value"]))
{

 $query .= 'OR buyer_order_date LIKE "%'.$_POST["search"]["value"].'%") ';
 
}

if(isset($_POST["order"]))
{
 $query .= 'ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
}
else
{
 $query .= 'ORDER BY id DESC ';
}

$query1 = '';

if($_POST["length"] != -1)
{
 $query1 .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$number_filter_row = mysqli_num_rows(mysqli_query($connect, $query));

$result = mysqli_query($connect, $query . $query1);

$data = array();

while($row = mysqli_fetch_array($result))
{
 $sub_array = array();
 $sub_array[] = $row["vendor_id"];
 $sub_array[] = $row["branch_id"];
 $sub_array[] = $row["invoice_no"];
 $sub_array[] = $row["round_of_amount"];
  $sub_array[] = $row["invoice_date"];
 $sub_array[] = $row["delivery_note"];
 $sub_array[] = $row["buyer_order_no"];
 $sub_array[] = $row["buyer_order_date"];
  $sub_array[] = $row["order_customer_name"];
 $sub_array[] = $row["delivery_date"];
 $sub_array[] = $row["dispatch_through"];
 $data[] = $sub_array;
}

function get_all_data($connect)
{
 $query = "SELECT * FROM purchase_inward";
 $result = mysqli_query($connect, $query);
 return mysqli_num_rows($result);
}

$output = array(
 "draw"    => intval($_POST["draw"]),
 "recordsTotal"  =>  get_all_data($connect),
 "recordsFiltered" => $number_filter_row,
 "data"    => $data
);

echo json_encode($output);

?>